package com.app.vista;

import org.eclipse.swt.widgets.Composite;

public class Composicion extends Composite {

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public Composicion(Composite parent, int style) {
		super(parent, style);

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
